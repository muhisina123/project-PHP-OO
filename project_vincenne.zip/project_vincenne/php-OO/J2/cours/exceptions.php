<?php
echo 'BBB';
/* 
Une Exception nous permet d'anticiper des erreurs qui pourraient arriver dans l'exécution de notre programme.

Pour utiliser les exceptions, on doit utiliser un bloc constitué d'au moins Try et Catch.

Try : On va dire à l'ordinateur d'ESSAYER de faire quelque chose.

Catch : Si il y a une erreur, qu'est-ce qu'on fait ?

        En PHP, il y a une règle 'spéciale' (dans le sens où elle n'est pas dans les autres langages) : Les exceptions, ce sont des objets qui ont été instanciés / créés par une classe Exception.

Optionnellement, on peut inclure un bloc 'finally'. 

Finally : Va s'exécuter dans tous les cas, après le bloc Try / Catch.
*/

try {
    #on essaye de se connecter à la base de données
    $pdo = new PDO('mysql:host=localhost;dbname=example;charset=utf8', 'root', '');
} catch (Exception $e) {
    # si cela a échoué, qu'est-ce qu'on fait ?
    echo "On arrive pas à se connecter !<br>";
} finally {
    # dans un bloc finally, les actions seront exécutées dans tous les cas
    echo "Réussi ou pas, au moins on a tenté<br>";
}

/* On ne va pas utilsier des Exceptions pour gérer des mauvais types de données, mais les fonctions prévues par PHP (is_int(), is_array(), ...) */

?>