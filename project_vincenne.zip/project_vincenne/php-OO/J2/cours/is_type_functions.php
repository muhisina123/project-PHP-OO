<?php

/*
On ne doit pas utiliser les exceptions tout le temps, mais seulement quand on a pas d'autres moyens.

Plutôt que d'utiliser des Exceptions, on peut regarder si le type des données sur lesquelles on veut travailler est bon.

Pour faire ceci, on a plusieurs fonctions. Chacune de ces fonctions renvoie un type Boléen (vrai ou faux, True ou False.)

Ces fonctions sont :

    - is_int() : est-ce que la donnée est de type integer ?
    - is_float() : ------------------------------- float ?
    - is_string() : chaîne de caractères (string)
    - is_object() : objet
    - is_bool() : booléen
    - is_array() : array
    - is_null() : null

Si on veut regarder si une valeur / donnée est une instance d'une classe qu'on a créé, on peut utiliser le mot-clé 'instanceof' :

    if ($objet instanceof MyClass) {
        # code à exécuter
    }

Grâce à tout cela, on peut regarder si les données sont du bon type avant de commencer à travailler dessus.
*/

function addition(int $x, int $y) {
    return $x + $y;
}

$str1 = 'Bonjour';
$str2 = 'Bonsoir';

if ((is_int($str1) == TRUE) && is_int($str2) == TRUE) {
    echo addition($str1, $str2);
} else {
    echo "Les données sont du mauvais type.";
}

# Code ci-dessous : même chose que ci-dessus, sauf que '== TRUE' et en réalité inutile (l'ordinateur comprend sans)
if (is_int($str1) && is_int($str2)) {
    echo addition($str1, $str2);
} else {
    echo "Les données sont du mauvais type.";
}
?>