<?php 
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['authenticated'])) {
    // Redirect to login page or display an error message
    header("Location: login.php");
    exit();
}
// if (!isset($_SESSION['BlogPost_id'])) {
//     // Redirect to login page or display an error message
//     header("Location: login.php");
//     exit();
// }
   
   class modification
{
  private $connection;

  public function __construct(PDO $connection)
  {
      $this->connection = $connection;
  }
  
  public function getBlogById($BlogPost_id)
  {
      $sql = "SELECT photo, title, description,user_id,id FROM blog WHERE id = :id";
      $stmt = $this->connection->prepare($sql);
      $stmt->bindParam(':id', $BlogPost_id, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetch(PDO::FETCH_ASSOC);
  }
  public function updateBlog($BlogPost_id, $title, $description, $photoName)
  {
      $sql = "UPDATE blog SET photo=:photo, title = :title, description = :description WHERE id = :id";
      $stmt = $this->connection->prepare($sql);
      $stmt->bindValue(':photo', $photoName);
      $stmt->bindParam(':id', $BlogPost_id, PDO::PARAM_INT);
      $stmt->bindParam(':title', $title, PDO::PARAM_STR);
      $stmt->bindParam(':description', $description, PDO::PARAM_STR);
      return $stmt->execute();
  }
}
try {
    $connection = new PDO("mysql:host=localhost;dbname=blog;charset=utf8", "root", "");
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $BlogPost_id = isset($_GET['blogpost']) ? $_GET['blogpost'] : null;
    echo $BlogPost_id;
   if ($BlogPost_id === null) {
       echo "Invalid blog-post ID.";
       exit;
   }

} catch(Exception $e){
   die($e->getMessage());

}
  
    $modification = new modification($connection);
    $selectedBlogPost = $modification->getBlogById($BlogPost_id);
    // var_dump($selectedBlogPost);
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit']) && isset($_POST['action']) && $_POST['action'] === 'update') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $photoName = $_FILES['photo']['name'];
        $photoTempName = $_FILES['photo']['tmp_name'];
      
        // Move the uploaded photo to a directory (replace with your directory path)
        $targetDirectory = 'assets\php\photos\\';
        $targetPath = $targetDirectory . $photoName;
        move_uploaded_file($photoTempName, $targetPath);
        $result=$modification->updateBlog($selectedBlogPost['id'],$title, $description, $photoName);
        
        }
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<?php if ($selectedBlogPost): ?>
  <!-- Add the edit form (initially hidden) -->
  <div id="editForm" style="text-align: center;">
  <form method="post" action="modify.php?blogpost=<?php echo $selectedBlogPost['id']; ?>" enctype="multipart/form-data">
      <input type="hidden" name="action" value="update">
      <input type="hidden" name="blog_id" value="<?php echo $selectedBlogPost['user_id']; ?>">
      <label for="title">Title:</label>
      <input type="text" name="title" value="<?php echo $selectedBlogPost['title']; ?>" required><br><br>
      <label for="description">Description:</label>
      <textarea name="description" rows="4" required><?php echo $selectedBlogPost['description']; ?></textarea><br><br>
      <label for="photo">Choose Photo:</label>
      <input type="file" name="photo" accept="image/*"><br><br>
      <button type="submit" name="submit" style="background-color: blue; border:none; color: white;">Update</button>
   </form>
    <?php if (isset($result)){
        if ($result) {
            echo "<div> Blog post updated successfully! </div>";
            header("Refresh: 1; URL=account.php");

        } else {
            echo "<div> Failed to update blog post.</div>";
        }}
        ?>
  </div>
<?php endif; ?>

<!-- ... -->
<!-- <script>
    function showEditForm() {
        // Hide the current display
        document.querySelector('#editForm').style.display = 'block';
    }
</script> -->
</body>
</html>