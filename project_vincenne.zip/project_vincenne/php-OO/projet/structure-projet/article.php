<?php
class Article
{
    private $connection;

    public function __construct(PDO $connection)
       {
        $this->connection = $connection;
    }

    public function getArticleById($articleId)
    {
        $sql = "SELECT * FROM blog WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindParam(':id', $articleId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function getotherarticle($articleId)
    {
        $sql = "SELECT id, photo, title FROM blog WHERE id != :id ORDER BY RAND() LIMIT 3";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindParam(':id', $articleId, PDO::PARAM_INT);
        $stmt->execute();
        $otherArticles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $otherArticles;
    }
}

try {
    $connection = new PDO("mysql:host=localhost;dbname=blog;charset=utf8", "root", "");
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $articleId = isset($_GET['id']) ? $_GET['id'] : null;
     //echo $articleId;
    if ($articleId === null) {
        echo "Invalid article ID.";
        exit;
    }

    $article = new Article($connection);
    $selectedArticle = $article->getArticleById($articleId);
    $otherArticles = $article->getotherarticle($articleId);
    if ($selectedArticle) {
        // Display the selected article
        echo "<div style='text-align: center;'>";
        echo "<h2>" . $selectedArticle['title'] . "</h2>";
        echo "<img src='assets/php/" . $selectedArticle['photo'] . "' alt='" . $selectedArticle['title'] . "'>";
        echo "<p>" . $selectedArticle['description'] . "</p>";
        echo "</div>";
    
        // Display the three other articles as thumbnails (e.g., title and photo)
        echo "<div style='display: flex; justify-content: center;'>";
        foreach ($otherArticles as $otherArticle) {
            echo "<div style='margin: 10px;'>";
            echo "<a href='article.php?id=" . $otherArticle['id'] . "'>";
            echo "<img src='assets/php/" . $otherArticle['photo'] . "' alt='" . $otherArticle['title'] . "'>";
            echo "<h2>" . $otherArticle['title'] . "</h2>";
            echo "</a>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "Article not found.";
    }
    
} catch (Exception $e) {
    die($e->getMessage());
}
?>
