
</head>
<body>
    <div class="container"><header> 
    <h1> 10 essential steps to open the door of optimism</h1>
   <form method="POST" action="index.php">
   <div class="middle">
   <a href="registration.php">
    <img class="profile_img" name="profile" src="assets\php\photos\user.jpg">
</a>
    <input class="textbox" type="text" name="search" placeholder="search">
    <button class="buttonsearch" name="submit"> <!-- Use name="submit" for the button -->
        <img class="searchbutton" src="assets/php/photos/search.svg">
        <div class="tooltip">search</div>
    </button>
    <label name="sort" for="sort">Sort by:</label>
    <select name="sort" id="sort">
        <option value="recent" name="recent">Most Recent</option>
        <option value="oldest"  name="oldest">Oldest</option>
    </select>
    
</form> 

  </div>
  
    </header>
    