<footer class="site-footer"><!-- Inside your HTML footer section -->
    <!-- Newsletter Subscription Form -->
    <div class="newsletter">
        <h3>Subscribe to Our Newsletter</h3>
        <p>Stay up-to-date with our latest news and updates.</p>
        
        <form action="subscribe.php" method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button class="subscribe-button" type="submit">Subscribe</button>
        </form>
    </div>
</footer>

</div>
</body>
</html>