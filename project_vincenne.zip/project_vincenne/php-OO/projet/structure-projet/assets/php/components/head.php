<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="././style.css"> 
    <style>
header{
background-color:black;
 margin-bottom:10px;  
}
   h1{
    padding-top:50px;
    color:white;
    text-align:center;
   }
   /* .middle {
  max-width: 500px;
  margin: 0 auto; /* This centers the container horizontally 
  display: flex;
  align-items: center;
}

.searchbutton {
  height: 20px;
  width: 40px;
}

.buttonsearch {
  height: 44px;
  border-color: rgb(192, 192, 192);
  border-width: 1px;
  border-style: solid;
  border-radius: 2px;
  box-shadow: inset 0px 1px 2px #eeeeee;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}*/


.middle {
  max-width: 500px;
  margin: 0 auto; /* This centers the container horizontally */
  display: flex;
  align-items: center;
  padding-bottom: 20px;

}

.textbox {
  flex: 1; /* This makes the input field expand to fill available space */
  height: 32px; /* Set the height to match the button */
  padding: 5px 10px; /* Adjust padding as needed */
  border: 1px solid #ccc;
  border-radius: 2px;
}

.buttonsearch {
  height: 44px;
  width: 44px; /* Set the width to match the height */
  border: none;
  background-color: white; /* Change to your preferred button color */
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.searchbutton {
  height: 20px;
  width: 20px; /* Set the width to match the height */
  fill: white; /* Change the icon color */
}

.tooltip {
  visibility: hidden;
  background-color: #333;
  color: #fff;
  text-align: center;
  border-radius: 5px;
  padding: 5px;
  position: absolute;
  z-index: 1;
  bottom: -30px;
  left: 50%;
  transform: translateX(-50%);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.buttonsearch:hover .tooltip {
  visibility: visible;
  opacity: 1;
}


/* Style the article container */
.article-container {
    display: flex; /* Use flexbox to create a horizontal layout */
    flex-wrap: wrap; /* Allow articles to wrap to the next line if the container is too narrow */
    justify-content: space-around; /* Space items evenly along the main axis (horizontally) */
}

/* Style individual articles */
.article {
    flex: 0 0 calc(33.33% - 20px); /* Set the width of each article (adjust as needed) */
    margin: 10px; /* Add spacing between articles */
    text-align: center;
}

/* Ensure a maximum width for images within articles */
.article img {
    max-width: 100%;
    height: auto;
}

/**************************************************************************
     
                                footer




************************************************************************** */

/* Center the footer content */
.site-footer {
    text-align: center;
    background-color: black; /* Set your desired background color */
    color: white; /* Set the font color to white */
    padding: 20px;
    margin-bottom:50px;
    margin-top:10px;
    height:200px;     
}

/* Style the newsletter subscription section */
.newsletter {
    margin-bottom: 20px;
}

/* Style the input field */
.newsletter input[type="email"] {
    padding: 10px;
    width: 250px;
}

/* Style the subscribe button */
.subscribe-button {
    padding: 10px 20px;
    background-color: red; /* Set the button color to red */
    color: white;
    border: none;
    cursor: pointer;
}

/*****************************************************************
                  profile
***********************************************************************/
.profile_img{
  height:40px;
  width: 25px;
  margin-right:20px ;
  border-radius:20px;
}
</style>