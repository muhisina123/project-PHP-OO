<?php
//session_start();
class Database
{
    private $host = 'localhost';
    private $dbname = 'blog';
    private $username = 'root';
    private $password = '';
    private $connection;
   

    public function __construct()
    {
        try {
            $this->connection = new PDO("mysql:host=$this->host;dbname=$this->dbname;charset=utf8", $this->username, $this->password);
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->totalarticle();

        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }

    public function getBlogData()
    {
        try {
            // SQL query to retrieve data from the blog table
            $sql = "SELECT id, photo, title, description FROM blog";

            // Prepare the statement
            $stmt = $this->connection->prepare($sql);

            // Execute the query
            $stmt->execute();

            // Fetch all rows as an associative array
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $result;
         } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }


    public function searchArticles($searchKeyword)
    {
        // Query to search for articles based on the keyword
        // $searchQuery = "SELECT id, photo, title, description FROM blog WHERE title LIKE :keyword";
        $searchQuery = "SELECT id, photo, title, description FROM blog WHERE title LIKE :keyword OR description LIKE :keyword";
        $stmt = $this->connection->prepare($searchQuery);
        $stmt->bindValue(':keyword', "%$searchKeyword%", PDO::PARAM_STR);
        $stmt->execute();

        // Fetch search results
        return $stmt->fetchAll(PDO::FETCH_ASSOC);


    //     // Debugging output
    // echo "Searching for: $searchKeyword<br>";


    // // Debugging output
    // var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
    // 
}

    public function totalarticle()
    {
        // Query to get the total number of articles
        $totalArticlesQuery = "SELECT COUNT(*) as total FROM blog";
        $totalArticlesStmt = $this->connection->query($totalArticlesQuery);
        $totalArticlesResult = $totalArticlesStmt->fetch(PDO::FETCH_ASSOC);
        $this->totalArticles = $totalArticlesResult['total'];
 
                // // Pagination variables
                // $this->itemsPerPage = 2;
                // $this->current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
                //     return  $this->current_page;
                // // Calculate the offset for the query
                // $this->offset = ($this->current_page - 1) * $this->itemsPerPage;
                // return   $this->offset;
    }

    public function currentarticle()
     {
         // Pagination variables
         $this->itemsPerPage = 2;
         $this->current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

         // Calculate the offset for the query
         $this->offset = ($this->current_page - 1) * $this->itemsPerPage;

        // Query to get the articles for the current page
        $articlesQuery = "SELECT id, photo, title, description FROM blog LIMIT :offset, :itemsPerPage";
        $stmt = $this->connection->prepare($articlesQuery);
        $stmt->bindValue(':offset', $this->offset, PDO::PARAM_INT);
        $stmt->bindValue(':itemsPerPage', $this->itemsPerPage, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function getOldestArticles()
    { // Pagination variables
        $this->itemsPerPage = 2;
        $this->current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;

        // Calculate the offset for the query
        $this->offset = ($this->current_page - 1) * $this->itemsPerPage;
        try {
            // SQL query to retrieve the recent articles from the blog table
            $sql = "SELECT id, photo, title, description FROM blog ORDER BY id DESC LIMIT :offset, :itemsPerPage";
            $stmt = $this->connection->prepare($sql);
            $stmt->bindValue(':offset', $this->offset, PDO::PARAM_INT);
            $stmt->bindValue(':itemsPerPage', $this->itemsPerPage, PDO::PARAM_INT);
            $stmt->execute();
    
            // Fetch all rows as an associative array
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            return $result;
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
    
    public function closeConnection()
    {
        $this->connection = null;
    }
}

class Blog
{
    private $data;
    private $itemsPerPage;
    private $current_page;
    private $totalPages;
    private $searchResults; // Add this line to define the property
    
    
    public function __construct($data, $current_page, $totalPages, $searchResults)
    {
        $this->data = $data;
        // $this->itemsPerPage = $itemsPerPage;
        $this->current_page = $current_page;
        $this->totalPages = $totalPages;
        $this->searchResults = $searchResults; // Add this line to set the property value
    }

    public function displayBlogPosts()
    {
    // Display search results
    if (count($this->searchResults)>0) {
        foreach ($this->searchResults as $result) {
            // Display each search result

            $id = $result['id'];
            $photo = $result['photo'];
            $title = $result['title'];
            $description = $result['description'];
          
            // Display the data as you see fit, for example:
            echo "<div style='text-align: center;'>";
            echo "<a href='article.php?id=$id'><img src='assets/php/photos/$photo' alt='$title'></a>";
            echo "<h2>$title</h2>";
            echo "<p>$description</p>";
            echo "</div>";
        }
    } 
    elseif(count($this->data)>0) {
            // Loop through each row and display the photo, title, and description
            echo "<div class='article-container'>";
            foreach ($this->data as $row) {
                $id = $row['id'];
                $photo = $row['photo'];
                $title = $row['title'];
                $description = $row['description'];
            
                // Wrap each article in a container
                echo "<div class='article'>";
                echo "<a href='article.php?id=$id'><img src='assets/php/photos/$photo' alt='$title'></a>";
                echo "<h2>$title</h2>";
                echo "<p>$description</p>";
                echo "</div>";
            }
            
            echo "</div>"; // Close the article-container
            

    } elseif (empty($this->searchResults)  || empty($this->data)) {
        echo "<div style='text-align: center;'>";
        echo "No match found";
        echo "</div>";
    
    }   

     // Generate pagination links
        echo "<div style='display: flex; justify-content: end;'>";
          if ($this->totalPages > 1) {
          if ($this->current_page > 1) {
              echo "<a href='index.php?page=" . ($this->current_page - 1) . "'>&laquo; Previous</a>";
          }
          for ($i = 1; $i <= $this->totalPages; $i++) {
              echo "<a href='index.php?page=$i'>$i</a>";
          }
          if ($this->current_page < $this->totalPages) {
              echo "<a href='index.php?page=" . ($this->current_page + 1) . "'>Next &raquo;</a>";
          }
       } else {
     echo "No records found in the database.";
 }
      echo "</div>";
   
}
}
?>

