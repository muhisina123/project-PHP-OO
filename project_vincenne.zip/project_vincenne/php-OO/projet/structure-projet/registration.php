<?php
 class Registration
{
    private $dbConnection;

    public function __construct($dbConnection)
    {
        $this->dbConnection = $dbConnection;
    }
    // public function generateToken($length = 32)
    // {
    //     return bin2hex(random_bytes($length));
    // }
    // public function sendVerificationEmail($email, $token)
    // {
    //     $subject = "Email Verification";
    //     $message = "Click the following link to verify your email:\n\n";
    //     $message .= "http://localhost/project_vincenne/php-OO/projet/structure-projet/registration.php?token=$token";

    //     $headers = "From: nilofur@gmail.com";

    //     return mail($email, $subject, $message, $headers);
    // }
    public function emailExists($email)
    {
        $sql = "SELECT COUNT(*) FROM bloggers WHERE email = :email";
        $stmt = $this->dbConnection->prepare($sql);
        $stmt->bindValue(':email', $email);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }


    public function registerUser($username, $email, $password)
    {
      if ($this->emailExists($email)) {
        return "Email already exists.";
    }
        $username = filter_var($username, FILTER_SANITIZE_STRING);
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return "Invalid email format.";
        }

        // Validate password (example: at least 8 characters with letters and numbers)
        if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
            return "Password must be at least 8 characters long and contain letters and numbers.";
        }

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Generate a verification token
      // $token = $this->generateToken();

      // Send verification email
      // if ($this->sendVerificationEmail($email, $token)) {
      //     echo "Verification email sent. Please check your inbox.";
      // } else {
      //     echo "Failed to send verification email.";
      //     return false;
      // }

        try {
            $sql = "INSERT INTO bloggers (username, email, password) VALUES (:username, :email, :password)";
            $stmt = $this->dbConnection->prepare($sql);
            $stmt->bindValue(':username', $username);
            $stmt->bindValue(':email', $email);
            $stmt->bindValue(':password', $hashedPassword);

            if ($stmt->execute()) {
                return true;
            } else {
                return "Registration failed.";
            }
        } catch (PDOException $e) {
            return "Database error: " . $e->getMessage();
        }
    }
}

// Create a database connection 
$host = 'localhost';
$dbname = 'blog';
$username = 'root';
$password = '';

$dbConnection = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create a registration instance
$registration = new Registration($dbConnection);

// Handle form submission
if (isset($_POST['submit'])) {
  // if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
     // echo $username.  " " .$email ." ". $password;
    // Register the user
    $result = $registration->registerUser($username, $email, $password);
    // if ($result === true) {
    //     echo "Registration successful!";
    // } else {
    //     echo $result;
    // }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>registration</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: purple;
    }

    .container {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    label {
      font-weight: bold;
    }

    input {
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      padding: 10px;
      background-color: purple;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
<h2>Register</h2>
    <form method="post" action="registration.php">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br><br>
        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required><br><br>
        <button type="submit" name="submit">Register</button>
        <a href="login.php">already have an account? <br><br><button>Login</button></a>
    </form>
    <?php if (!empty($result)): ?>
  <div class="message">
  <?php   if ($result === true) {
         echo "Registration successful!";
         header("Refresh: 5;  URL= account.php"); // Redirect to success page after 5 seconds
         exit();
     } else {
         echo $result;
        // header("Refresh: 5;  URL= registration.php"); // Redirect back to the registration  page after 5 seconds
         exit();
     }  ?>
     </div>
    <?php endif; ?>
</div></body>
</html>