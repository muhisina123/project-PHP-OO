<?php
session_start();

if (!isset($_SESSION['authenticated'])) {
    // Redirect to login page or display an error message
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    // Redirect to an error page or display an error message
    header("Location: error.php");
    exit();
}

$blogId = $_GET['id'];

try {
    $connection = new PDO("mysql:host=localhost;dbname=blog;charset=utf8", "root", "");
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the logged-in user has permission to delete this blog post
    $sql = "SELECT user_id FROM blog WHERE id = :id";
    $stmt = $connection->prepare($sql);
    $stmt->bindParam(':id', $blogId, PDO::PARAM_INT);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row || $_SESSION['id'] != $row['user_id']) {
        // User does not have permission to delete this post
        // Redirect to an access denied page or display an error message
        header("Location: access_denied.php");
        exit();
    }

    // Delete the blog post
    $sql = "DELETE FROM blog WHERE id = :id";
    $stmt = $connection->prepare($sql);
    $stmt->bindParam(':id', $blogId, PDO::PARAM_INT);
    $stmt->execute();

    // Redirect to a success page or display a success message
    header("Location: account.php");
    exit();
} catch (Exception $e) {
    // Handle any errors that occur during the deletion process
    // You can redirect to an error page or display an error message here
    die($e->getMessage());
}
?>
