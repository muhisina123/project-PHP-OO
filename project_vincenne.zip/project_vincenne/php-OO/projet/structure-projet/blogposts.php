<?php
session_start();

// Check if the user is authenticated
if (!isset($_SESSION['authenticated'])) {
    // Redirect to login page or display an error message
    header("Location: login.php");
    exit();
}

class Blogposts
{
  private $connection;

  public function __construct(PDO $connection)
  {
      $this->connection = $connection;
  }
  public function getBlogById($Id)
  {
      $sql = "SELECT photo, title, description,user_id FROM blog WHERE id = :id";
      $stmt = $this->connection->prepare($sql);
      $stmt->bindParam(':id', $Id, PDO::PARAM_INT);
      $stmt->execute();
      return $stmt->fetch(PDO::FETCH_ASSOC);
  }
}

try {
    $connection = new PDO("mysql:host=localhost;dbname=blog;charset=utf8", "root", "");
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $Id = isset($_GET['id']) ? $_GET['id'] : null;
     //echo $Id;
    if ($Id === null) {
        echo "Invalid blog-post ID.";
        exit;
    }

  
    $Blogposts = new Blogposts($connection);
    $selectedBlogPost = $Blogposts->getBlogById($Id);
    if ($selectedBlogPost) {
      if ($_SESSION['id'] == $selectedBlogPost['user_id']) {

      // Display the selected article
      echo "<div class='container'>";
      echo "<div>";
      echo "<div style='text-align: center;'>";
      echo "<h2>" . $selectedBlogPost['title'] . "</h2>";
      echo "<img style='max-width: 50%; height: auto;' src='assets/php/photos/{$selectedBlogPost['photo']}'>";
      echo "<p>" . $selectedBlogPost['description'] . "</p>";
      echo '<a href="modify.php?blogpost=' . $Id . '"><button style="margin-right: 10px; border:none ;background-color: blue; color: white;">Modify & Save</button></a>';
      echo '<button onclick="confirmDelete(' . $Id . ');" style="background-color: red; border:none; color: white;" name="delete">Delete</button>';
      echo "</div>";
      echo "</div>";
      echo "</div>";
    }else {
      // User does not have permission to view the article
      // Redirect to an access denied page or display an error message
      header("Location: access_denied.php");
      exit();
      }
     } else {
      header("Location: 404.php");
      exit();
    }
  } catch (Exception $e) {
    die($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>.img {
    max-width: 100%;
    height: auto;
}</style>
</head>
<body>
  <script>function confirmDelete(blogId) {
    if (confirm("Are you sure you want to delete this blog post?")) {
      // If the user clicks "OK" in the confirmation dialog, proceed with deletion
      window.location.href = "delete.php?id=" + blogId; // Replace "delete.php" with the actual deletion script
    }
  }</script>
</body>
</html>