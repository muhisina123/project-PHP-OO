<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session at the top of account.php  . initializes a session or resumes the current one. Sessions are used to store user data across multiple pages or requests.
session_start();
// $_SESSION['email'] = $email; // Store user's ID/email in a session variable

// Check if the user is authenticated
if (!isset($_SESSION['id'])) {
    // User is not authenticated, redirect to login page
    header("Location: login.php");
    exit(); // Make sure to exit after a header redirect
}
// Check if the user is authenticated
if (!isset($_SESSION['authenticated'])) {
  // Redirect to login page or display an error message
  header("Location: login.php");
  exit();
}
// Retrieve user ID from the session
$user_id = $_SESSION['id'];// Store user's ID/email in a session variable

class Blog{

  private $dbConnection;
  public function __construct($dbConnection)
  {
      $this->dbConnection = $dbConnection;
  }

  public function insertBlogPost($title, $description, $photoName,$user_id)
  {
      // Prepare and execute the SQL query to insert blog post
      $sql = "INSERT INTO blog (title, description, photo,user_id) VALUES (:title, :description, :photo,:user_id)";
      $stmt = $this->dbConnection->prepare($sql);
      $stmt->bindValue(':title', $title);
      $stmt->bindValue(':description', $description);
      $stmt->bindValue(':photo', $photoName);
      $stmt->bindValue(':user_id', $user_id);
      return $stmt->execute();
      if ($stmt->execute()) {
        echo "Article uploaded successfully!";
    } else {
        echo "Article upload failed.";
    }
  }
    public function showblogposts($user_id,$dbConnection)
    {    
// Assuming $dbConnection is your database connection
$sql = "SELECT * FROM blog WHERE user_id = :user_id";
$stmt = $dbConnection->prepare($sql);
$stmt->bindValue(':user_id', $user_id);
$stmt->execute();
 return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
}

// Create a database connection (replace with your actual database configuration)
$host = 'localhost';
$dbname = 'blog';
$username = 'root';
$password = '';

$dbConnection = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create a Blog instance
$blog = new Blog($dbConnection);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
  $title = $_POST['title'];
  $description = $_POST['description'];
  $photoName = $_FILES['photo']['name'];
  $photoTempName = $_FILES['photo']['tmp_name'];

  // Move the uploaded photo to a directory (replace with your directory path)
  $targetDirectory = 'assets\php\photos\\';
  $targetPath = $targetDirectory . $photoName;
  move_uploaded_file($photoTempName, $targetPath);
  $result=$blog->insertBlogPost($title, $description, $photoName,$user_id);
  }
  $blogPosts = $blog->showblogposts($user_id,$dbConnection);

  if (isset($_POST['logout'])) {
    // Unset all session variables  Unsets all session variables using $_SESSION = array();. This effectively clears all session data.
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to registration.php
    header("Location: registration.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Upload Photo</title>
  <link rel="stylesheet" href="php-OO\projet\structure-projet\assets\css\style.css">
  <style>w
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f0f0f0;
      flex-direction: column; /* Stack children vertically */

    }

    .container {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin:15%;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    label {
      font-weight: bold;
    }

    input[type="text"], textarea {
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      padding: 10px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    .blog-grid {
            display: flex; /* Display the posts in a row */
            flex-wrap: wrap; /* Wrap the posts to the next row if they overflow */
            gap: 20px; /* Add some spacing between posts */
        }

        .blog-post {
            width: calc(33.33% - 20px); /* Set the width of each post (adjust as needed) */
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .blog-post img {
    max-width: 100%;
    height: auto;
}
.header {
        background-color: black;
        padding: 10px 0; /* Add padding to create some space around the text */
        text-align: center; /* Center-align the text horizontally */
        width: 100%;
    }
    .logout,.posts{
      color:black;
      background-color:white;
      
    }

    /* Style the header text */
    .header h1 {
        margin: 0; /* Remove margin from the h1 element */
    }
    .buttons_header{
      display:flex;
      justify-content:center;
      align-items:center;
      gap: 90%;
      margin-right: 10px;
      margin-left: 10px;
       
    }

  </style>
   
</head>
<body>
  <div class="header"> 
        <h1 style="color: white;">Your Blog Account</h1>
        <div class=buttons_header>
        <!-- <a href="registration.php"><button name="logout" class="logout">Logout</button></a> -->
        <a href="#blog-grid">
          <button class="posts">Posts</button>
        </a>
        <form method="post">
        <button name="logout" class="logout">Logout</button>
        </form>
    </div>
    </div>
     <div class="container">
    <h2>Upload Photo</h2>
    <!--  echo "<div>" . $_SESSION['id'] . "</div>"; ?> -->
    <form method="post" action="account.php" enctype="multipart/form-data">
      <label for="title">Title:</label>
      <input type="text" name="title" required><br><br>
      <label for="description">Description:</label>
      <textarea name="description" rows="4" required></textarea><br><br>
      <label for="photo">Choose Photo:</label>
      <input type="file"  name="photo" accept="image/*" required><br><br>
      <button type="submit" name="submit">Upload</button>
      <?php // Insert blog post
  if (isset($result)) {
    echo "<div class='message'>Blog post inserted successfully! </div>"; 
  } else {
      echo "<div class='message'>Failed to insert blog post.</div>";
  }  ?>
    </form>
    </div>
    <div id="blog-grid" class="container">
    <?php if($blogPosts) {?>
        <h2  >Your Blog Posts</h2>
        <div  class="blog-grid">
            <?php
            foreach ($blogPosts as $post) {
                echo "<div class='blog-post'>";
                echo "<a href='blogposts.php?id=" . $post['id'] . "'> <img src='assets/php/photos/{$post['photo']}'></a>";
                // echo "<a href='blogposts.php?id=$post['id']'> <img src='assets/php/photos/{$post['photo']}'> </a>";
                echo "<h3>{$post['title']}</h3>";
                echo "<p>{$post['description']}</p>";
                echo "</div>";
                // Additional details like the post date or author can be displayed here.
            } } else {
            
            ?>   
            
            <h2>No Blog Posts to show</h2> 
            <?php } ?>

        </div>
    </div>
  <script>
    // Remove the message after 1 second
    setTimeout(function () {
      var message = document.querySelector('.message');
      if (message) {
        message.style.display = 'none';
      }
    }, 1000); // 1000 milliseconds = 1 second
    
    // document.querySelector('.posts').addEventListener('click', function(event) {
    //     event.preventDefault(); // Prevent the default anchor link behavior
    //     document.getElementByid('blog-grid').scrollIntoView({ behavior: 'smooth' });
    // });

    </script>
</body>
</html>
