<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start(); // Start the session at the top of the PHP script


class Login
{
  private $dbConnection;

  public function __construct($dbConnection)
  {
      $this->dbConnection = $dbConnection;
  }
  
  public function loginUser($email, $password)
  {
    try {
      $sql = "SELECT id, password FROM bloggers WHERE email = :email";
      $stmt = $this->dbConnection->prepare($sql);
      $stmt->bindValue(':email', $email);
      $stmt->execute();
      $userData = $stmt->fetch(PDO::FETCH_ASSOC);

      if ($userData && password_verify($password, $userData['password'])) {
        return $userData['id'];
      } else {
        return false;
      }

    } catch (PDOException $e) {
      return "Database error: " . $e->getMessage();
    }
  }
}

// Create a database connection 
$host = 'localhost';
$dbname = 'blog';
$username = 'root';
$password = '';

$dbConnection = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
$dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create a login instance
$login = new Login($dbConnection);

if (isset($_POST['submit'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Login user
  $result = $login->loginUser($email, $password);
  
  // if ($result !== false) {
  //   echo "Login successful!";
  //   echo $result;
  //   // You can set up session and redirect logic here
  //   header("Refresh: 1; URL=account.php"); // Redirect to success page after 5 seconds
  //   exit();
  // } else {
  //   echo "Login failed.";
  // }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: purple;
    }

    .container {
      background-color: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    label {
      font-weight: bold;
    }

    input {
      padding: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    button {
      padding: 10px;
      background-color: purple;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Login</h2>
    <form method="post" action="login.php">
        <label for="email">Email:</label>
        <input type="email" name="email" required><br><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required><br><br>
        <button type="submit" name="submit">Login</button>
        <?php
if (isset($result)) {
 // echo $result;
if ($result !== false) {
  $user_id = $result; // Assuming $result contains the user ID
   // After successful login
   //echo $user_id;
   // After successful login
$_SESSION['authenticated'] = true;
$_SESSION['id'] = $user_id; // Store user's ID/email in a session variable
  echo "<div class='message'>Login successful! </div>"; 
  

// ... perform user authentication ...

// Regenerate the session ID
session_regenerate_id(true);

// Continue with other operations...

  // You can set up session and redirect logic here
  header("Refresh: 1; URL=account.php"); // Redirect to the account page after 1 second
  //echo $result;
  exit();
} else {
  echo "<div class='message'>Login failed.</div>";
}
}
?>
    </form>
  </div>

  <script>
    // Remove the message after 1 second
    setTimeout(function () {
      var message = document.querySelector('.message');
      if (message) {
        message.style.display = 'none';
      }
    }, 1000); // 1000 milliseconds = 1 second
    </script>
</body>
</html>
