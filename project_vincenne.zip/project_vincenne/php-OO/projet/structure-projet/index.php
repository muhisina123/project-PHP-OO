<?php
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

include './assets/php/components/head.php';
// Debugging output
//var_dump($_POST);
?>

    <title>Page d'accueil</title>

<?php
include './assets/php/components/header.php';
 
require './assets/php/database/init.php';

// Create a database object
$database = new Database();

$dataToDisplay = $database->getOldestArticles();
//print_r($dataToDisplay);

$searchResults = null;
// Get the blog data
$blogData = $database->currentarticle();
//print_r($blogData);

/****************************************************************
 * 
 *                   search  bar code
 * 
 * 
 * ***************************************************************
 */


if (isset($_POST['search'])) {
    $searchKeyword = $_POST['search'];
    //var_dump($searchKeyword);
    if (!empty($searchKeyword)) {
        // Fetch search results
        $searchResults = $database->searchArticles($searchKeyword);
            //var_dump($searchResults);
    }

} else {
    // If search keyword is not set, get all articles
    // $blogData = $database->getBlogData();

// Get the blog data
$blogData = $database->currentarticle();
}


// Calculate the total number of pages
$totalPages = ceil($database->totalArticles / $database->itemsPerPage);

/**************************************************************************************
 *  
 * 
 *                      sorting code
 * 
 * 
 * *************************************************************************************
 */

// Check if a sorting option is selected
// $sortOption = isset($_POST['sort']) ? $_POST['sort'] : 'oldest';
if( isset($_POST['sort']))
{
    $sortOption = $_POST['sort'];

// Get the blog data based on the sorting option
if ($sortOption === 'recent') {
    $sortedData = $database->currentarticle(); 
    //var_dump( $sortedData);
    // By default, it sorts by most recent
} elseif ($sortOption === 'oldest'){
    // Get the blog data sorted by oldest
    $sortedData = $database->getOldestArticles();
   //var_dump($sortedData);
}
 


//Determine which data to use based on search results and sorting option
if (isset($searchResults) && count($searchResults) > 0) {
    // Display search results
    $dataToDisplay = $searchResults;
    
} elseif (isset($sortedData) && count($sortedData) > 0) {
    // Display sorted data
    $dataToDisplay = $sortedData;
} else {
    // Display default data (most recent articles)
    $dataToDisplay = $blogData;
}

}


// Create a blog object with all necessary data
//  $blog = new Blog(isset($searchResults) ? $searchResults : $blogData, $database->current_page, $totalPages, $searchResults);
// $blog = new Blog(($sortOption === 'recent' ? $blogData : $searchResults), $database->current_page, $totalPages, $searchResults);


 $blog = new Blog($dataToDisplay, $database->current_page, $totalPages, $searchResults);




// Display the blog posts with pagination
$blog->displayBlogPosts();

// Close the database connection
$database->closeConnection();

/* Ici, on fera nos traitements de données */
?>
<!--  include './assets/php/components/head.php';
?>

    <title>Page d'accueil</title>
    <p>hi</p>


include './assets/php/components/header.php';
?> -->


<!-- Ici, il y aura le contenu de la page -->

<!-- 
 include './assets/php/components/article.php';
?>  -->

<?php
include './assets/php/components/footer.php';
?>

