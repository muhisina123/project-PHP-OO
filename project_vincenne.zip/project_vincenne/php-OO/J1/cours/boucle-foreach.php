Une boucle foreach nous permet de réaliser une action sur un élément 'itérable'. 

'Itérable' : il a plusieurs éléments.

Par exemple, pour afficher l'ensemble des éléments d'un tableau :

    foreach ($tableau as $tab) {
        echo $tab;
    }

On peut aussi afficher l'ensemble des propriétés d'un objet :

    foreach ($objet as $propriete) {
        echo $propriete;
    }
