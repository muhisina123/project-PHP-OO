<?php

# Sur la page d'accueil de Youtube, on nous propose plusieurs vidéos. On remarque que chacune de ces vidéos est affichée avec la même structure.

# Pour réaliser ceci, on va créer une class Card, qui va nous permettre d'afficher l'ensemble de ces vidéos de la même façon.

class Card {
    # on déclare nos propriétés
    public int $id;
    public string $miniature;
    public string $titre;
    public string $auteur;
    public int $nombreVues;

    public function __construct(int $idCard, string $photo, string $titreVideo, string $createur, int $nbVues) {
        $this->id = $idCard;
        $this->miniature = $photo;
        $this->titre = $titreVideo;
        $this->auteur = $createur;
        $this->nombreVues = $nbVues;
    }

    public function afficher() {
        echo "
            <div style=\"border: solid 0.2em black;\">
                <img src=\"$this->miniature\" width=\"300\">
                <br>
                $this->titre
                <br>
                $this->auteur
                <br>
                $this->nombreVues
                <br>
                <a href=\"card.php?supprimer=$this->id\">Supprimer</a>
            </div>
        ";
    }

    public function incrVues() {
        $this->nombreVues = $this->nombreVues + 1;
        
    }

    public function changerMiniature(string $nouvelleMiniature) {
        $this->miniature = $nouvelleMiniature;
    }

    public function changerTitre(string $nouveauTitre) {
        $this->titre = $nouveauTitre;
    }
}

/* $obj = new Card(0, './assets/img-php-oo.jpg', 'Vidéo 1', 'Squeezie', 0);

echo "Nombre de vues avant incrémentation : $obj->nombreVues<br>";
$obj->incrVues();

echo "Card avec iniature initiale :";
$obj->afficher();

$obj->changerMiniature('./assets/miniature2.jpg');

echo "Card avec la nouvelle miniature :";
$obj->afficher();

echo "Card avec le titre initial :";
$obj->afficher();

$obj->changerTitre('Nouveau titre !');

echo "Card avec le nouveau titre :";
$obj->afficher();
*/

# Exercice 4 (bouton supprimmer)
for ($i = 0; $i < 20; $i++) {
    $obj = new Card($i, './assets/img-php-oo.jpg', 'Vidéo 1', 'Squeezie', 0);
    echo "ID de la card : $obj->id";
    $obj->afficher();
} 


# Pour aller plus loin (ne pas afficher la Card qui vient d'être supprimée)
/* for ($i = 0; $i < 20; $i++) {
    if (isset($_GET['supprimer']) && $i == $_GET['supprimer']) {
        echo "La card qui a comme ID $i a été supprimée !<br>";
    } else {
        $obj = new Card($i, './assets/img-php-oo.jpg', 'Vidéo 1', 'Squeezie', 0);
        echo "ID de la card : $obj->id";
        $obj->afficher();
    }
} */

?>