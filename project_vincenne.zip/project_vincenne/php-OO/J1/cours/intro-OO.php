<?php

/* Pour programmer en PROCEDURAL, on va écrire une instruction après l'autre. 

1 - on va créer deux variable
2 - si la première est supérieur à la seconde, on affiche la première à l'écran
3 - si la seconde n'est pas inférieure à la première, on affiche la seconde à l'éran

*/

$variableA = 10;
$variableB = 12;

if ($variableA > $variableB) {
    echo $variableA;
} else {
    echo $variableB;
}


/* Pour faire la même chose en FONCTIONNEL, on va créer une fonction */

function comparaison(int $nb1, int $nb2) {
    if ($nb1 > $nb2) {
        echo $nb1;
    } else {
        echo $nb2;
    }
}

comparaison(10, 15);
comparaison($variableA, $variableB);


/* Pour faire la même chose en ORIENTE-OBJET, on va créer une classe */

class Comparateur {
    # au début d'une classe, on déclare ses propriétés
    # pour l'instant, on ne leur assigne pas de valeur
    public int $nombreA;
    public int $nombreB;
    #une fois les deux propriétés ci-dessus déclarées, notre objet, quand il sera créé; aura comme propriété $nombreA et $nombreB

    # on crée notre fonction d'initialisation
    public function __construct(int $nb1, int $nb2) {
        # on assigne une valeur à la propriété $nombreA
        $this->nombreA = $nb1;
        # on assigne une valeur à la propriété $nombreB
        $this->nombreB = $nb2;
    }

    # une fois notre fonction d'initialisaiton créée, on va pouvoir ajouter des méthodes à notre objet
    # par exemple, ici, notre Comparateur aura une méthode 'comparaison' qui renvoie la propriété $nombreA de l'objet si elle est supérieur à la propriété $nombreB, ou $nombreB si on est pas dans cette condition.
    public function comparaison() {
        if ($this->nombreA > $this->nombreB) {
            echo $this->nombreA;
        } else {
            echo $this->nombreB;
        }
    }
}

# une fois la classe créée, on va pouvoir créer une nouvel objet en l'assignant à une variable
$comp = new Comparateur(11, 22);

# une fois qu'on a créé l'objet, on va pouvoir utiliser ses méthodes
$comp->comparaison();

?>
