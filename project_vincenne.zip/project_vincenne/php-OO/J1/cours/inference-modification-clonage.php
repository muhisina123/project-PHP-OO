<?php

class Voiture {
    #on déclare les propriétés de notre objet Voiture
    public string $marque;
    public int $puissance;

    public function __construct(string $marqueVoiture, int $puissanceVoiture) {
        $this->marque = $marqueVoiture;
        $this->puissance = $puissanceVoiture;
    }

    # Les méthodes peuvent être catégorisées dans trois cas d'utilisation généraux :

        # Inférence : faire des choses

        # Modification : modifier un ou plusieurs éléments

        # Clonage : pour dupliquer l'objet

    # Inférence : l'objet réalise une action (ici, il affiche une information à l'écran)
    public function afficher_marque() {
        echo $this->marque;
    }

    # Modification : on modifie une valeur d'une propriété de l'objet
    public function reprog() {
        $this->puissance = $this->puissance + 20;
    }

    # Clonage : pour cloner l'objet
    public function clone() {
        return new Voiture($this->marque, $this->puissance);
    }
}

$obj = new Voiture('Mercedes', 200);
# pour créer un clone :
$obj2 = $obj->clone();

?>