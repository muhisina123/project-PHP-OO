<?php

# Pour faire une requête SQL, on va avoir besoin de 3 choses :

    # La requête à faire

    # Préparer la requête

    # Exécuter la requête


# étape 1 : la requête à faire
$texteReq = "INSERT INTO example (nom, prenom) VALUES ('Vincent', 'Spinosa')";
# étape 2 : on prépare la requête
$query = $pdo->prepare($texteReq);
# étape 3 : on exécute la requête
$query->execute();

/* 
Avec cette méthode, il y a une chose à laquelle i faut faire attention :

    Si on envoie une chaîne de caractères à la base de données, il ne faut pas oublier de mettre notre valeur ou variable elle-même entre guillemets avant de les envoyer à la Base de données
 */

# EXEMPLE  :

$prenom = 'Vincent';
$nom = 'Spinosa';

# Ci-dessous, il ne faut pas oublier de mettre les variables $prenom et $nom entre guillemets quand on les envoie à la BDD. En effet, si les guillemets sont visibles sur notre fichier de code, il ne sont en réalité qu'une aide indiquant que la valeur de la variable est du texte / une chaîne de caractères. Il faut donc remettre les guillemets autour du nom de la variable, pour que la base de données comprenne elle-aussi que la valeur est une chaîne de caractères ! ;)
$texteReq = "INSERT INTO example (nom, prenom) VALUES ('$prenom', '$nom')";

?>